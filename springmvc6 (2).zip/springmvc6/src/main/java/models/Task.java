package models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="task")
public class Task {
@Id	
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int taskid;
@Column
private String tasktitle;
@Column
private String taskdesc;
@Column
private int empid;
public int getTaskid() {
	return taskid;
}
public void setTaskid(int taskid) {
	this.taskid = taskid;
}
public String getTasktitle() {
	return tasktitle;
}
public void setTasktitle(String tasktitle) {
	this.tasktitle = tasktitle;
}
public String getTaskdesc() {
	return taskdesc;
}
public void setTaskdesc(String taskdesc) {
	this.taskdesc = taskdesc;
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}


}
