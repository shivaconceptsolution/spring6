package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.SI;
import services.Swap;
@Controller
public class SwapController {
	@RequestMapping(value = "/swap", method = RequestMethod.GET)
    public ModelAndView swapLoad() {
      return new ModelAndView("swap", "command", new Swap());
     }
	@RequestMapping(value = "/swapcode", method = RequestMethod.POST)
    public ModelAndView swapCode(@ModelAttribute("springmvc6")Swap obj) {
	  int temp=obj.getNum1();
	  obj.setNum1(obj.getNum2());
	  obj.setNum2(temp);
     ModelAndView model= new ModelAndView("swap", "command", new Swap());
     model.addObject("key", "num1="+obj.getNum1() + " num2="+obj.getNum2());
     return model;
     }
  
}
