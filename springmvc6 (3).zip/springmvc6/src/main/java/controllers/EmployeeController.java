package controllers;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import models.Emp;
import services.Empbean;

@Controller
public class EmployeeController {
	@RequestMapping("emp")
     public ModelAndView empInfo(){

    	return new ModelAndView("empview","command",new Empbean());

    }	
	@RequestMapping("empinsert")
    public ModelAndView empInsert(@ModelAttribute("springmvc6")Empbean s){
		Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory sf = cfg.buildSessionFactory();
        Session sess = sf.openSession();
        Transaction tx= sess.beginTransaction();
        Emp obj = new Emp();
        obj.setEmpid(s.getEmpid());
        obj.setEmpname(s.getEmpname());
        obj.setJob(s.getJob());
        sess.save(obj);
        tx.commit();
        sess.close();
		ModelAndView obj1= new ModelAndView("empview","command",new Empbean());
		obj1.addObject("res","data inserted successfully");
		return obj1;

   }
	
}
