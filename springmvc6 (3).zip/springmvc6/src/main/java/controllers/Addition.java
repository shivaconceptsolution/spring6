package controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Addition {
	@RequestMapping("addload")
	public ModelAndView addition()
	{
		
		return new ModelAndView("add");
	}
	
	@RequestMapping("addlogic")
	public ModelAndView additionLogic(HttpServletRequest request,HttpServletResponse response)
	{
		int num1 = Integer.parseInt(request.getParameter("txtnum1"));
		int num2 = Integer.parseInt(request.getParameter("txtnum2"));
		int num3 = num1+num2;
		ModelAndView obj= new ModelAndView("addresult","key",num3);
		obj.addObject("key1","1001");
		obj.addObject("key2","1002");
		List<String> lst = new ArrayList<String>();
		lst.add("C");
		lst.add("C++");
		lst.add("JAVA");
		obj.addObject("key3",lst);
		return obj;
	}

}
